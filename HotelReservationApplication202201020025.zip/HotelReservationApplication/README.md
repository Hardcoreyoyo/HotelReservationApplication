202201020025

build something  
Menu: CreateAnAccount ， UserCheckReservation

<br>
<br>
<br>

202201012218

build something  
Menu: Add a Room 

<br>
<br>
<br>

202201011832

build something  
void: getRecommandRoom，RecommandDate  

modify Menu is used if instead switch

<br>
<br>
<br>

202201010238

Modify all Resource

<br>
<br>
<br>

202201010005

study for hashCode ， equals  
think about Algorithm optimize for intersection and union
conclusion:  
Date is not bigger enough to use Algorithm optimize

<br>
<br>
<br>

202112311709

Build something
void: FindRooms，CheckDateRange

<br>
<br>
<br>

202112310808

make custom annotation ?

<br>
<br>
<br>


202112302353

Resource modify Check

<br>
<br>
<br>

202112292213

prepare void reserveARoom that check data

<br>
<br>
<br>

202112281914

build something  
void: displayAllReservations，getReservations，reserveARoom。  

<br>
<br>
<br>

202112280211

change something
void: addRoom。(obey Requirements)


<br>
<br>
<br>

202112280034

change something
SINGLETON: AdminService，CustomerService。
void: getAllUser，getAllRoom。(obey Requirements)


<br>
<br>
<br>

202112272259

build something
SINGLETON: UserDataBase，RoomDataBase。
void: getAllUser，getAllRoom，addRoom。


<br>
<br>
<br>

202112271921

fucking SINGLETON  
solve lose data while new Class every time  

<br>
<br>
<br>


202112271459

Solution:  
interface must override all void, abstract is not.  
override void which is not used empty.  
maybe change package structure to make sense.  
using scanner.close careful  

<br>
<br>
<br>

202112250136

try to understand How is interface work in big structure.
Is necessary to use static in void ?

<br>
<br>
<br>

202112250136

Build rough structure  

add:   
interface resource  
Service sub package  
IRoom like dao  
test email  
create all i need Model  

Date system requirement is more simpler ?  
create all i need Model but dont figure out how is working together

<br>
<br>
<br>

202112242307

Build rough structure  
How to Implement Date system ?

<br>
<br>
<br>