package HotelReservationApplication.Model;

public enum RoomType {
    Single,
    Double
}
